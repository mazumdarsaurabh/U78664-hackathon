from django.urls import path
from . import views

urlpatterns = [
    path('', views.employee_form, name='employee_form'),
    path('', views.employee_list, name='employee_list'),
    path('jumble/', views.jumble_word, name='jumble_word')
]

