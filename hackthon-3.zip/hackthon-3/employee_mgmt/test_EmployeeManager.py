import unittest
from employee import Employee
from employee_manager import EmployeeManager

import unittest
from employee import Employee
from employee_manager import EmployeeManager
 
class TestEmployeeManager(unittest.TestCase):
    def setUp(self):
        self.manager = EmployeeManager()
        self.emp1 = Employee("Anil","Telecom", "Tester", 30000, 100, 2000,1000)
        self.emp2 = Employee("Sunil", "IT", "Programmer", 5500, 450, 250,2000)
        self.manager.add_employee(self.emp1)
        self.manager.add_employee(self.emp2)
 
    def test_add_employee(self):
        self.assertEqual(len(self.manager.get_all_employees()), 2)
 
    def test_find_employee_by_id(self):
        found = self.manager.find_by_id(self.emp1.id)
        self.assertIsNotNone(found)
        self.assertEqual(found.name, "Anil")
 
    def test_delete_employee(self):
        result = self.manager.delete_employee(self.emp1.id)
        self.assertTrue(result)
        self.assertEqual(len(self.manager.get_all_employees()), 1)
 
if __name__ == '__main__':
    unittest.main()