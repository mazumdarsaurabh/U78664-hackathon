import unittest
from employee import Employee

class TestEmployee(unittest.TestCase):
    def setUp(self):
        self.employee = Employee("Anil", "Telecom", " Engineer", 30000, 100, 2000,31900)

    def test_net_salary_calculation(self):
        self.assertEqual(self.employee.net_salary,31900 )

    def test_employee_attributes(self):
        self.assertEqual(self.employee.name, "Anil")
        self.assertEqual(self.employee.department, "Telecom")
        self.assertEqual(self.employee.designation, " Engineer")
        
        

if __name__ == '__main__':
    unittest.main()