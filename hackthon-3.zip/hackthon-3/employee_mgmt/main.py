from employee_manager import EmployeeManager
from storage import Storage
from employee import Employee

def main():
    manager = EmployeeManager()
    manager.employees = Storage.load()

def display_employees(employees):
    if not employees:
        print("No Employee found with this details")
    for s in employees:
        print(f"{s.id} - {s.name}, Department: {s.department}, Designation: {s.designation}, Gross_Salary:{s.gross_salary},Tax:{s.tax}, Bonus:{bonus},Net_Salary:{s.net_salary} ")

    saved_data = storage.load()
    manager.load_employees(saved_data)
while True:
        print("\n1. Add Employee\n2. View All\n3. Search by ID\n4. Delete an Employee\n5. Exit")
        choice = input("Enter choice: ")

        if choice == '1':
            name = input("Name: ")
            department = input("Enter your Department: ")
            designation = input("Enter your Designation: ")
            gross_salary=input("Enter your Gross_Salary")
            tax=input("Enter tax")
            bonus=input("Enter bonus")
            employee = manager.add_employee(name,department, designation,gross_salary,tax,bonus)
            storage.save(manager.to_dict_list())
            print(f"Employee added with ID: {employee.id}")
        elif choice == '2':
            display_employees(manager.get_all_employees())

        elif choice == '3':
            sid = input("Enter employee ID: ")
            employee = manager.find_by_id(sid)
            if employee:
                print(sid)
            else:
                print("No such Employee found .")
        elif choice =='4':
            sid = input("Enter employee ID to delete: ")
            if manager.delete_employee(sid):
                print("Employee deleted.")
            else:
                print("Employee not found.")


        elif choice == '5':
            Storage.save(manager.employees)
            print("Exiting.")
            break
        else:
            print("Invalid choice!")

if __name__ == "__main__":
    main()