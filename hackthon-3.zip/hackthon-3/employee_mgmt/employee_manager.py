import pickle
from employee import Employee

class EmployeeManager:
    def __init__(self):
        self.employees = []
    def add_employee(self, employee):
        
        self.employees.append(employee)
        return employee
    def get_all_employees(self):
        return self.employees
    def find_by_id(self, employee_id):
        return next((s for s in self.employees if s.id == employee_id), None)
    def delete_employee(self, employee_id):
        employee = self.find_by_id(employee_id)
        if employee:
            self.employees.remove(employee)
            return True
        return False
    def save_data(self):
        with open(self.filename, 'wb') as file:
            pickle.dump(self.employees, file)
    def load_data(self):
        try:
            with open(self.filename, 'rb') as file:
                self.employees = pickle.load(file)
        except FileNotFoundError:
            self.employees = {}
